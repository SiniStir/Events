document.getElementById('scroll-to-download').addEventListener('click', function() {
    document.getElementById('download').scrollIntoView({ behavior: 'smooth' });
});
